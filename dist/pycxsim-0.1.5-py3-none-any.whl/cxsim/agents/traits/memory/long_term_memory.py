

class LongTermMemory:
    def __init__(self, capacity: int):
        pass