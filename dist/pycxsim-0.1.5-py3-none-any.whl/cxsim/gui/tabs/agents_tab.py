class AgentTab:
    pass