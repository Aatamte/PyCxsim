import pathlib
ASSET_PATH = pathlib.Path(__file__).parent