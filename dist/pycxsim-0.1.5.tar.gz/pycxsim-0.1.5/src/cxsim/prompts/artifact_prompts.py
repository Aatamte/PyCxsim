from src.cxsim import Prompt

marketplace_prompt = Prompt(
    """A Marketplace exists in the simulation"""
)

