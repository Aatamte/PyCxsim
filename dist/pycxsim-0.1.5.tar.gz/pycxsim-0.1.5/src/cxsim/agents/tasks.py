

class Tasks:
    def __int__(self):
        pass


class Task:
    def __int__(
            self
    ):
        pass

    def add(self):

        pass