Overview
========

PyCxsim is a comprehensive Python package designed for [brief description of the package's main purpose]. This section provides a detailed overview of the package, its core concepts, features, and more.

.. toctree::
   :maxdepth: 2
   :hidden:

   what_is_pycxsim
   key_features
   why_choose_pycxsim
   core_concepts
