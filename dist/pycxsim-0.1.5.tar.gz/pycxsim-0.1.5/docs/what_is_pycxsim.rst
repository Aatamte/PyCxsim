What is PyCxsim?
================

PyCxsim at its core consists of:

- Environment
- Agents
- Artifacts

