Simulation of "An Experimental Study of Competitive Market Behavior" by Vernon Smith
============================


You can find the original paper here:

https://digitalcommons.chapman.edu/cgi/viewcontent.cgi?article=1027&context=economics_articles



Test 1 replication: